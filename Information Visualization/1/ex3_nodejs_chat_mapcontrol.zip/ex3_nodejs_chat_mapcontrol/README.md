Run file app.js in Nodejs
If you want to use it, you should read and edit it, because when I create it, I am just a Nodejs newbie